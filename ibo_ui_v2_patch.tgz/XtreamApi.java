package com.monopolio.mediaplayeribo;

import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class XtreamApi {
    public static final class Category {
        public final String id, name;
        public Category(String id, String name) { this.id=id; this.name=name; }
        @Override public String toString(){ return name; }
    }

    public static final class Item {
        public final String name, id, ext, kind, categoryId, icon, backdrop, plot, rating, year, duration;
        public Item(String name, String id, String ext, String kind, String categoryId, String icon, String backdrop, String plot, String rating, String year, String duration) {
            this.name=name; this.id=id; this.ext=ext; this.kind=kind; this.categoryId=categoryId; this.icon=icon; this.backdrop=backdrop; this.plot=plot; this.rating=rating; this.year=year; this.duration=duration;
        }
        @Override public String toString(){ return name; }
    }

    private static String base(String server) {
        String s=server==null?"":server.trim(); while(s.endsWith("/"))s=s.substring(0,s.length()-1); return s;
    }
    private static String api(PanelApi.Config c,String action) {
        return base(c.server)+"/player_api.php?username="+Uri.encode(c.username)+"&password="+Uri.encode(c.password)+"&action="+action;
    }
    private static String get(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(30000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","MediaPlayerIbo/2.0");
        int code=c.getResponseCode();InputStream input=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder sb=new StringBuilder();
        if(input!=null)try(BufferedReader br=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}finally{c.disconnect();}
        if(code<200||code>=300)throw new Exception("Servidor IPTV HTTP "+code);return sb.toString();
    }

    public static List<Category> categories(PanelApi.Config c,String kind)throws Exception{
        String action="live".equals(kind)?"get_live_categories":"movie".equals(kind)?"get_vod_categories":"get_series_categories";
        JSONArray a=new JSONArray(get(api(c,action)));List<Category> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String id=x.optString("category_id","");String n=x.optString("category_name","");if(!id.isEmpty()&&!n.isEmpty())out.add(new Category(id,n));}
        return out;
    }

    public static List<Item> items(PanelApi.Config c,String kind)throws Exception{
        String action="live".equals(kind)?"get_live_streams":"movie".equals(kind)?"get_vod_streams":"get_series";
        JSONArray a=new JSONArray(get(api(c,action)));List<Item> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;
            if("series".equals(kind)){
                String id=String.valueOf(x.opt("series_id"));if("null".equals(id)||id.isEmpty())continue;
                String back=backdrop(x.opt("backdrop_path"));
                out.add(new Item(x.optString("name","Serie "+id),id,"","series",x.optString("category_id",""),x.optString("cover",""),back,x.optString("plot",""),x.optString("rating",""),x.optString("year",x.optString("releaseDate","")),x.optString("episode_run_time","")));
            } else {
                String id=String.valueOf(x.opt("stream_id"));if("null".equals(id)||id.isEmpty())continue;
                String icon=x.optString("stream_icon","");
                String name=x.optString("name",("live".equals(kind)?"Canal ":"Película ")+id);
                String ext="live".equals(kind)?"ts":x.optString("container_extension","mp4");
                out.add(new Item(name,id,ext,kind,x.optString("category_id",""),icon,"",x.optString("plot",""),x.optString("rating",""),x.optString("year",x.optString("releasedate","")),x.optString("duration","")));
            }
        }
        return out;
    }

    public static List<Item> episodes(PanelApi.Config c,String seriesId)throws Exception{
        JSONObject root=new JSONObject(get(api(c,"get_series_info")+"&series_id="+Uri.encode(seriesId)));JSONObject eps=root.optJSONObject("episodes");List<Item> out=new ArrayList<>();if(eps==null)return out;
        Iterator<String> keys=eps.keys();while(keys.hasNext()){String season=keys.next();JSONArray arr=eps.optJSONArray(season);if(arr==null)continue;for(int i=0;i<arr.length();i++){
            JSONObject x=arr.optJSONObject(i);if(x==null)continue;String id=String.valueOf(x.opt("id"));if("null".equals(id)||id.isEmpty())continue;JSONObject info=x.optJSONObject("info");
            String icon=info==null?"":info.optString("movie_image",info.optString("cover_big",""));String plot=info==null?"":info.optString("plot","");String rating=info==null?"":info.optString("rating","");String duration=info==null?"":info.optString("duration","");
            out.add(new Item("T"+season+" · "+x.optString("title","Episodio "+(i+1)),id,x.optString("container_extension","mp4"),"episode","",icon,"",plot,rating,"",duration));
        }}return out;
    }

    public static String playback(PanelApi.Config c,Item item,String liveFormat){
        String b=base(c.server),u=Uri.encode(c.username),p=Uri.encode(c.password),id=Uri.encode(item.id);
        if("movie".equals(item.kind))return b+"/movie/"+u+"/"+p+"/"+id+"."+(item.ext.isEmpty()?"mp4":item.ext);
        if("episode".equals(item.kind))return b+"/series/"+u+"/"+p+"/"+id+"."+(item.ext.isEmpty()?"mp4":item.ext);
        String ext="m3u8".equals(liveFormat)?"m3u8":"ts";return b+"/live/"+u+"/"+p+"/"+id+"."+ext;
    }

    private static String backdrop(Object o){
        if(o==null)return "";if(o instanceof JSONArray){JSONArray a=(JSONArray)o;return a.length()>0?a.optString(0,""):"";}String s=String.valueOf(o);if(s.startsWith("[")&&s.endsWith("]")){try{JSONArray a=new JSONArray(s);return a.length()>0?a.optString(0,""):"";}catch(Exception ignored){}}return s;
    }
}
