package com.monopolio.mediaplayeribo;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class AppPrefs {
    private final SharedPreferences p;

    public AppPrefs(Context c) { p = c.getSharedPreferences("ibo_prefs_v2", Context.MODE_PRIVATE); }

    public String language() { return p.getString("language", "es"); }
    public void language(String v) { p.edit().putString("language", v).apply(); }

    public String theme() { return p.getString("theme", "teal"); }
    public void theme(String v) { p.edit().putString("theme", v).apply(); }

    public String liveFormat() { return p.getString("live_format", "ts"); }
    public String liveOrder() { return p.getString("live_order", "server"); }
    public void liveOrder(String v) { p.edit().putString("live_order", v).apply(); }
    public String mediaSort() { return p.getString("media_sort", "server"); }
    public void mediaSort(String v) { p.edit().putString("media_sort", v).apply(); }
    public void liveFormat(String v) { p.edit().putString("live_format", v).apply(); }

    public String playerMode() { return p.getString("player_mode", "internal"); }
    public void playerMode(String v) { p.edit().putString("player_mode", v).apply(); }

    public String externalPackage() { return p.getString("external_package", ""); }
    public void externalPackage(String v) { p.edit().putString("external_package", v == null ? "" : v).apply(); }

    public boolean autoPreview() { return p.getBoolean("auto_preview", false); }
    public void autoPreview(boolean v) { p.edit().putBoolean("auto_preview", v).apply(); }

    public String timeFormat() { return p.getString("time_format", "24"); }
    public void timeFormat(String v) { p.edit().putString("time_format", v).apply(); }

    public boolean subtitles() { return p.getBoolean("subtitles", true); }
    public void subtitles(boolean v) { p.edit().putBoolean("subtitles", v).apply(); }

    public String subtitleSize() { return p.getString("subtitle_size", "normal"); }
    public void subtitleSize(String v) { p.edit().putString("subtitle_size", v).apply(); }

    public String deviceType() { return p.getString("device_type", "auto"); }
    public void deviceType(String v) { p.edit().putString("device_type", v).apply(); }

    public boolean parentalEnabled() { return p.getBoolean("parental_enabled", false); }
    public void parentalEnabled(boolean v) { p.edit().putBoolean("parental_enabled", v).apply(); }

    public String parentalPin() { return p.getString("parental_pin", "0000"); }
    public void parentalPin(String v) { p.edit().putString("parental_pin", v).apply(); }

    public Set<String> hiddenCategories(String kind) {
        return new LinkedHashSet<>(p.getStringSet("hidden_" + kind, Collections.emptySet()));
    }
    public void hiddenCategories(String kind, Set<String> ids) {
        p.edit().putStringSet("hidden_" + kind, new LinkedHashSet<>(ids)).apply();
    }

    public boolean isFavorite(String kind, String id) { return p.getStringSet("fav_" + kind, Collections.emptySet()).contains(id); }
    public void toggleFavorite(String kind, String id) {
        Set<String> s = new LinkedHashSet<>(p.getStringSet("fav_" + kind, Collections.emptySet()));
        if (!s.add(id)) s.remove(id);
        p.edit().putStringSet("fav_" + kind, s).apply();
    }
    public Set<String> favorites(String kind) { return new LinkedHashSet<>(p.getStringSet("fav_" + kind, Collections.emptySet())); }

    public void addRecent(String kind, String id) {
        List<String> xs = recent(kind);
        xs.remove(id);
        xs.add(0, id);
        if (xs.size() > 60) xs = xs.subList(0, 60);
        p.edit().putString("recent_" + kind, join(xs)).apply();
    }
    public List<String> recent(String kind) {
        String raw = p.getString("recent_" + kind, "");
        if (raw == null || raw.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(raw.split("\\|")));
    }
    public void clearRecent(String kind) {
        SharedPreferences.Editor e = p.edit().remove("recent_" + kind);
        if (!"live".equals(kind)) {
            for (String k : p.getAll().keySet()) if (k.startsWith("resume_" + kind + "_")) e.remove(k);
        }
        e.apply();
    }

    public void saveResume(String kind, String id, long positionMs) {
        if (positionMs < 5000) positionMs = 0;
        p.edit().putLong("resume_" + kind + "_" + id, positionMs).apply();
    }
    public long resume(String kind, String id) { return p.getLong("resume_" + kind + "_" + id, 0L); }

    private static String join(List<String> xs) {
        StringBuilder b = new StringBuilder();
        for (String x : xs) {
            if (x == null || x.isEmpty()) continue;
            if (b.length() > 0) b.append('|');
            b.append(x.replace("|", ""));
        }
        return b.toString();
    }
}
